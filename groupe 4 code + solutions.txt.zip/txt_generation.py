
with open('output/out.txt','w') as f:
    f.write('taskId;performed;employeeName;startTime;\n')
    f.write('ok')